;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;;;;;;                                                          ;;;;;;;;
;;;;;;  All files in this directory and its subdirectories are  ;;;;;;;;
;;;;;;  copyright 1997, 1998, 1999, 2000, 2002.                 ;;;;;;;;
;;;;;;  by Rafael D. Sorkin.  All rights reserved.              ;;;;;;;;
;;;;;;                                                          ;;;;;;;;
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

; bibliotek.constants  Time-stamp:<2002-Dec-16 22:11:17 15870.38357>

;: Why this bibliotek?  

; These constant definitions were originally isolated here to avoid
; compilation, which caused trouble for elisp, once upon a time.

;; Package info needed here? see { ~/lisp/bibliotek.TCL.l } for sample.

;: Some mathematical constants like pi and e 

(defconstant the-number-pi 
  3.1415926535897932384626433832795028841972      " Pi to 40 places")
(defconstant pi%  the-number-pi                   " Pi to 40 places")

(defconstant the-number-e 
  2.7182818284590452353602874713526624977572      " e to 40 places")
(defconstant e%  the-number-e                     " e to 40 places")

(defconstant Euler% 
  0.5772156649015328606065120900824024310422  " Euler's constant to 40 places")

(defconstant log_sqrt_2pi  (/ (log (* 2 pi%)) 2))

;: Some powers of 2 

(defconstant 2^3  8)
(defconstant 2^4  16)
(defconstant 2^5  32)
(defconstant 2^6  64)
(defconstant 2^7  128)
(defconstant 2^8  256)
(defconstant 2^9  512)
(defconstant 2^10 1024)
(defconstant 2^11 2048)
(defconstant 2^12 4096)
(defconstant 2^13 8192)
(defconstant 2^14 16384)
(defconstant 2^15 32768)
(defconstant 2^16 65536)

(defconstant 2^17 (expt 2 17))
(defconstant 2^18 (expt 2 18))
(defconstant 2^19 (expt 2 19))
(defconstant 2^20 (expt 2 20))
(defconstant 2^21 (expt 2 21))
(defconstant 2^22 (expt 2 22))
(defconstant 2^23 (expt 2 23))
(defconstant 2^24 (expt 2 24))
(defconstant 2^25 (expt 2 25))
(defconstant 2^26 (expt 2 26))

;: Some constants of nature

(defconstant c%   2.99792458e+10 "cm/s, c is now exact, ``speed of light''")

(defconstant k%   1.3806503e-16 "(24) erg/K  Boltzmann constant")

(defconstant 8piG 
  1.6771e-06 "(25) cm^3/g s^2, rationalized gravitational constant kappa")

(defconstant G%   6.673e-08 "(10) cm^3/g s^2,  Newton constant")

(defconstant hbar 1.054571596e-27 "(82) erg s")

(defconstant eps_0 (/ 25 pi% c% c%) "C^2 s^2/g cm^3, exact")

(defconstant e_e 1.602176462e-19 "(63) C, electron charge")

(defconstant m_e  9.10938188e-28 "(72) g, electron mass")


;; Give them their units (but not good for TCL since it folds case

(put 'c% 'units 'cm/s)
(put 'k% 'units 'erg/K)
(put '8piG 'units 'cm^3/g-s^2)
(put 'G% 'units 'cm^3/g-s^2)
(put 'hbar 'units 'erg-s)
(put 'eps_0 'units 'C^2-s^2/g-cm^3) 
(put 'e_e 'units 'C)			
(put 'm_e 'units 'g)

;: end 
